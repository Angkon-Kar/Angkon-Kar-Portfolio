// ============================================================
// popup.js — UI only. All timer truth lives in background.js;
// this file renders it and sends action messages.
// ============================================================

const html = document.documentElement;
const themeSelect = document.getElementById("themeSelect");
const liveClock = document.getElementById("liveClock");
const tabs = document.querySelectorAll(".tab-btn");
const tabContents = document.querySelectorAll(".tab-content");

// --- Real-time Clock ---
setInterval(() => {
  liveClock.innerText = new Date().toLocaleTimeString();
}, 1000);

// --- Theme Management ---
chrome.storage.local.get(["theme"], (res) => {
  if (res.theme) {
    html.setAttribute("data-theme", res.theme);
    themeSelect.value = res.theme;
  }
});
themeSelect.addEventListener("change", (e) => {
  const val = e.target.value;
  html.setAttribute("data-theme", val);
  chrome.storage.local.set({ theme: val });
});

// --- Tab Switching ---
tabs.forEach(tab => {
  tab.addEventListener("click", () => {
    tabs.forEach(t => t.classList.remove("active"));
    tabContents.forEach(c => c.classList.remove("active"));
    tab.classList.add("active");
    document.getElementById(tab.dataset.tab).classList.add("active");
    if (tab.dataset.tab === "stats") renderStats();
  });
});

// --- Messaging helper (talks to background.js) ---
function sendMessage(msg) {
  return new Promise((resolve) => chrome.runtime.sendMessage(msg, resolve));
}

// ============================================================
// Timer
// ============================================================
const timeDisplay = document.getElementById("timeDisplay");
const startBtn = document.getElementById("startBtn");
const pauseBtn = document.getElementById("pauseBtn");
const resetBtn = document.getElementById("resetBtn");
const sessionInfo = document.getElementById("sessionInfo");
const modeRadios = document.getElementsByName("mode");

let currentState = null;
let currentSettings = null;
let currentStats = {};
let tickId = null;

function formatTime(totalSeconds) {
  totalSeconds = Math.max(0, Math.floor(totalSeconds));
  const m = Math.floor(totalSeconds / 60).toString().padStart(2, "0");
  const s = (totalSeconds % 60).toString().padStart(2, "0");
  return `${m}:${s}`;
}

function minutesForMode(mode) {
  if (mode === "pomodoro") return currentSettings.pomodoro;
  if (mode === "shortBreak") return currentSettings.shortBreak;
  if (mode === "longBreak") return currentSettings.longBreak;
  return 0;
}

function updateBadge(text, color) {
  chrome.action.setBadgeText({ text });
  if (color) chrome.action.setBadgeBackgroundColor({ color });
}

function stopTicking() {
  if (tickId) clearInterval(tickId);
  tickId = null;
}

function renderIdleDisplay() {
  if (currentState.mode === "stopwatch") {
    timeDisplay.innerText = formatTime((currentState.stopwatchBase || 0) / 1000);
  } else {
    const totalMs = currentState.remainingMs != null
      ? currentState.remainingMs
      : minutesForMode(currentState.mode) * 60000;
    timeDisplay.innerText = formatTime(totalMs / 1000);
  }
}

function waitForCompletion(retries = 6) {
  setTimeout(async () => {
    await refreshState();
    if (currentState.status === "running" && retries > 0) {
      waitForCompletion(retries - 1);
    }
  }, 700);
}

function startTicking() {
  stopTicking();
  tickId = setInterval(() => {
    if (currentState.mode === "stopwatch") {
      const elapsed = Date.now() - currentState.stopwatchStartedAt;
      const formatted = formatTime(elapsed / 1000);
      timeDisplay.innerText = formatted;
      updateBadge(formatted, "#4f46e5");
    } else {
      const remaining = currentState.endTime - Date.now();
      if (remaining <= 0) {
        timeDisplay.innerText = "00:00";
        stopTicking();
        waitForCompletion();
        return;
      }
      timeDisplay.innerText = formatTime(remaining / 1000);
      updateBadge(Math.ceil(remaining / 60000) + "m", "#4f46e5");
    }
  }, 1000);
}

function todayKeyLocal() {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}

const MODE_LABELS = { pomodoro: "Focus", shortBreak: "Short Break", longBreak: "Long Break", stopwatch: "Stopwatch" };

function applyStateToUI() {
  [...modeRadios].forEach(r => { r.checked = r.value === currentState.mode; });

  stopTicking();
  if (currentState.status === "running") {
    startBtn.innerText = "Running...";
    startBtn.disabled = true;
    pauseBtn.disabled = false;
    if (currentState.mode === "stopwatch") {
      timeDisplay.innerText = formatTime((Date.now() - currentState.stopwatchStartedAt) / 1000);
    } else {
      timeDisplay.innerText = formatTime(Math.max(0, currentState.endTime - Date.now()) / 1000);
    }
    startTicking();
  } else {
    startBtn.innerText = currentState.status === "paused" ? "Resume" : "Start";
    startBtn.disabled = false;
    pauseBtn.disabled = true;
    updateBadge("");
    renderIdleDisplay();
  }

  const todayCount = currentStats[todayKeyLocal()] || 0;
  sessionInfo.innerText = `Mode: ${MODE_LABELS[currentState.mode]} · Sessions today: ${todayCount}`;
}

async function refreshState() {
  const res = await sendMessage({ type: "GET_STATE" });
  currentState = res.state;
  currentSettings = res.settings;
  currentStats = res.stats;
  applyStateToUI();
}

modeRadios.forEach(radio => {
  radio.addEventListener("change", async (e) => {
    if (currentState.status === "running") {
      [...modeRadios].forEach(r => { r.checked = r.value === currentState.mode; });
      return;
    }
    const res = await sendMessage({ type: "SET_MODE", mode: e.target.value });
    currentState = res.state;
    applyStateToUI();
  });
});

startBtn.addEventListener("click", async () => {
  const res = await sendMessage({ type: "START" });
  currentState = res.state;
  applyStateToUI();
});

pauseBtn.addEventListener("click", async () => {
  const res = await sendMessage({ type: "PAUSE" });
  currentState = res.state;
  applyStateToUI();
});

resetBtn.addEventListener("click", async () => {
  const res = await sendMessage({ type: "RESET" });
  currentState = res.state;
  applyStateToUI();
});

// ============================================================
// To-Do List (DOM-built, not innerHTML — avoids CSP/XSS issues
// with task text that contains special characters)
// ============================================================
const taskInput = document.getElementById("newTask");
const taskList = document.getElementById("taskList");
const addTaskBtn = document.getElementById("addTaskBtn");

function getTasks() {
  return new Promise(resolve => chrome.storage.local.get(["tasks"], res => resolve(res.tasks || [])));
}

function renderTasks(tasks) {
  taskList.innerHTML = "";
  tasks.forEach((t, index) => {
    const li = document.createElement("li");
    li.className = t.done ? "task-done" : "";

    const span = document.createElement("span");
    span.innerText = t.text;
    span.addEventListener("click", () => toggleTask(index));

    const delBtn = document.createElement("button");
    delBtn.className = "delete-btn";
    delBtn.innerText = "×";
    delBtn.addEventListener("click", (e) => {
      e.stopPropagation();
      deleteTask(index);
    });

    li.appendChild(span);
    li.appendChild(delBtn);
    taskList.appendChild(li);
  });
}

async function saveTasks(tasks) {
  await chrome.storage.local.set({ tasks });
  renderTasks(tasks);
}

getTasks().then(renderTasks);

async function addTask() {
  const text = taskInput.value.trim();
  if (!text) return;
  const tasks = await getTasks();
  tasks.push({ text, done: false });
  await saveTasks(tasks);
  taskInput.value = "";
}

addTaskBtn.addEventListener("click", addTask);
taskInput.addEventListener("keydown", (e) => { if (e.key === "Enter") addTask(); });

async function toggleTask(index) {
  const tasks = await getTasks();
  tasks[index].done = !tasks[index].done;
  await saveTasks(tasks);
}

async function deleteTask(index) {
  const tasks = await getTasks();
  tasks.splice(index, 1);
  await saveTasks(tasks);
}

// ============================================================
// Analytics — real session counts, last 7 days
// ============================================================
let focusChart = null;

function last7DaysLabelsAndData(stats) {
  const labels = [];
  const data = [];
  for (let i = 6; i >= 0; i--) {
    const d = new Date();
    d.setDate(d.getDate() - i);
    const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
    labels.push(d.toLocaleDateString(undefined, { weekday: "short" }));
    data.push(stats[key] || 0);
  }
  return { labels, data };
}

function renderStats() {
  const { labels, data } = last7DaysLabelsAndData(currentStats || {});
  const ctx = document.getElementById("focusChart").getContext("2d");

  if (focusChart) {
    focusChart.data.labels = labels;
    focusChart.data.datasets[0].data = data;
    focusChart.update();
    return;
  }

  focusChart = new Chart(ctx, {
    type: "bar",
    data: {
      labels,
      datasets: [{
        label: "Focus Sessions",
        data,
        backgroundColor: "#4f46e5",
        borderRadius: 4
      }]
    },
    options: {
      scales: {
        y: { beginAtZero: true, ticks: { color: "#9ca3af", precision: 0 } },
        x: { ticks: { color: "#9ca3af" } }
      },
      plugins: { legend: { display: false } }
    }
  });
}

// ============================================================
// Settings
// ============================================================
const setPomodoro = document.getElementById("setPomodoro");
const setShortBreak = document.getElementById("setShortBreak");
const setLongBreak = document.getElementById("setLongBreak");
const setIntervalInput = document.getElementById("setInterval");
const setSound = document.getElementById("setSound");
const saveSettingsBtn = document.getElementById("saveSettingsBtn");

function fillSettingsForm() {
  setPomodoro.value = currentSettings.pomodoro;
  setShortBreak.value = currentSettings.shortBreak;
  setLongBreak.value = currentSettings.longBreak;
  setIntervalInput.value = currentSettings.longBreakInterval;
  setSound.checked = currentSettings.soundEnabled;
}

saveSettingsBtn.addEventListener("click", async () => {
  const updated = {
    pomodoro: Math.max(1, parseInt(setPomodoro.value, 10) || 25),
    shortBreak: Math.max(1, parseInt(setShortBreak.value, 10) || 5),
    longBreak: Math.max(1, parseInt(setLongBreak.value, 10) || 15),
    longBreakInterval: Math.max(2, parseInt(setIntervalInput.value, 10) || 4),
    soundEnabled: setSound.checked
  };
  const res = await sendMessage({ type: "SAVE_SETTINGS", settings: updated });
  currentSettings = res.settings;
  if (currentState.status !== "running") renderIdleDisplay();

  saveSettingsBtn.innerText = "Saved ✓";
  setTimeout(() => { saveSettingsBtn.innerText = "Save Settings"; }, 1200);
});

// ============================================================
// Init
// ============================================================
(async function init() {
  await refreshState();
  fillSettingsForm();
})();

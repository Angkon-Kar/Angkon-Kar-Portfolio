// ============================================================
// background.js — Service worker: owns all timer state so it
// survives the popup being closed (MV3 popups are destroyed on
// close, so state MUST live here, not in popup.js).
// ============================================================

const DEFAULT_SETTINGS = {
  pomodoro: 25,
  shortBreak: 5,
  longBreak: 15,
  longBreakInterval: 4,
  soundEnabled: true
};

const DEFAULT_STATE = {
  mode: "pomodoro",       // pomodoro | shortBreak | longBreak | stopwatch
  status: "idle",         // idle | running | paused
  endTime: null,          // countdown modes: ms timestamp when timer ends
  remainingMs: null,      // countdown modes: ms left, set when paused
  stopwatchBase: 0,       // stopwatch: accumulated ms before the last resume
  stopwatchStartedAt: null, // stopwatch: ms timestamp of last resume
  pomodoroCycle: 0        // completed focus sessions since last long break
};

async function getSettings() {
  const { settings } = await chrome.storage.local.get("settings");
  return { ...DEFAULT_SETTINGS, ...(settings || {}) };
}

async function getState() {
  const { timerState } = await chrome.storage.local.get("timerState");
  return { ...DEFAULT_STATE, ...(timerState || {}) };
}

async function setState(patch) {
  const state = await getState();
  const next = { ...state, ...patch };
  await chrome.storage.local.set({ timerState: next });
  return next;
}

function todayKey() {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}

async function recordCompletedSession() {
  const { stats } = await chrome.storage.local.get("stats");
  const s = stats || {};
  const key = todayKey();
  s[key] = (s[key] || 0) + 1;
  await chrome.storage.local.set({ stats: s });
}

function minutesForMode(mode, settings) {
  if (mode === "pomodoro") return settings.pomodoro;
  if (mode === "shortBreak") return settings.shortBreak;
  if (mode === "longBreak") return settings.longBreak;
  return 0;
}

// --- Message handling from popup.js ---
chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  handleMessage(msg).then(sendResponse);
  return true; // keep the channel open for the async response
});

async function handleMessage(msg) {
  const settings = await getSettings();
  let state = await getState();

  switch (msg.type) {
    case "GET_STATE": {
      const { stats } = await chrome.storage.local.get("stats");
      return { state, settings, stats: stats || {} };
    }

    case "SET_MODE": {
      if (state.status === "running") return { state }; // ignore, guarded in UI too
      await chrome.alarms.clear("focusTimer");
      state = await setState({
        mode: msg.mode,
        status: "idle",
        endTime: null,
        remainingMs: null,
        stopwatchBase: 0,
        stopwatchStartedAt: null
      });
      chrome.action.setBadgeText({ text: "" });
      return { state };
    }

    case "START": {
      if (state.mode === "stopwatch") {
        const startedAt = Date.now() - (state.stopwatchBase || 0);
        state = await setState({ status: "running", stopwatchStartedAt: startedAt });
      } else {
        const totalMs = state.remainingMs != null
          ? state.remainingMs
          : minutesForMode(state.mode, settings) * 60 * 1000;
        const endTime = Date.now() + totalMs;
        await chrome.alarms.create("focusTimer", { when: endTime });
        state = await setState({ status: "running", endTime, remainingMs: null });
      }
      return { state };
    }

    case "PAUSE": {
      if (state.mode === "stopwatch") {
        const elapsed = Date.now() - (state.stopwatchStartedAt || Date.now());
        state = await setState({
          status: "paused",
          stopwatchBase: (state.stopwatchBase || 0) + elapsed,
          stopwatchStartedAt: null
        });
      } else {
        await chrome.alarms.clear("focusTimer");
        const remainingMs = Math.max(0, (state.endTime || Date.now()) - Date.now());
        state = await setState({ status: "paused", remainingMs, endTime: null });
      }
      chrome.action.setBadgeText({ text: "" });
      return { state };
    }

    case "RESET": {
      await chrome.alarms.clear("focusTimer");
      state = await setState({
        status: "idle",
        endTime: null,
        remainingMs: null,
        stopwatchBase: 0,
        stopwatchStartedAt: null
      });
      chrome.action.setBadgeText({ text: "" });
      return { state };
    }

    case "SAVE_SETTINGS": {
      const next = { ...settings, ...msg.settings };
      await chrome.storage.local.set({ settings: next });
      return { settings: next };
    }

    default:
      return {};
  }
}

// --- Countdown finished (fires even if the popup is closed) ---
chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name !== "focusTimer") return;

  const settings = await getSettings();
  let state = await getState();

  chrome.action.setBadgeText({ text: "DONE" });
  chrome.action.setBadgeBackgroundColor({ color: "#22c55e" });

  let title, message, nextMode;

  if (state.mode === "pomodoro") {
    await recordCompletedSession();
    const cycle = (state.pomodoroCycle || 0) + 1;
    nextMode = cycle % settings.longBreakInterval === 0 ? "longBreak" : "shortBreak";
    await setState({
      status: "idle",
      endTime: null,
      remainingMs: null,
      pomodoroCycle: cycle,
      mode: nextMode
    });
    title = "Focus session complete!";
    message = nextMode === "longBreak"
      ? "Great streak — you've earned a long break."
      : "Nice work. Take a short break.";
  } else {
    nextMode = "pomodoro";
    await setState({ status: "idle", endTime: null, remainingMs: null, mode: nextMode });
    title = "Break's over!";
    message = "Ready to start another focus session?";
  }

  if (settings.soundEnabled) {
    chrome.notifications.create({
      type: "basic",
      iconUrl: "icon.png",
      title,
      message,
      priority: 2
    });
  }
});
